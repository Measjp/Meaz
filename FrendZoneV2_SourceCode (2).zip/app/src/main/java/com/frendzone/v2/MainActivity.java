package com.frendzone.v2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button signupButton = findViewById(R.id.button_signup);
        Button bookButton = findViewById(R.id.button_book);
        Button incomeButton = findViewById(R.id.button_income);

        signupButton.setOnClickListener(v -> Toast.makeText(this, "Companion sign-up coming soon!", Toast.LENGTH_SHORT).show());
        bookButton.setOnClickListener(v -> Toast.makeText(this, "Booking feature coming soon!", Toast.LENGTH_SHORT).show());
        incomeButton.setOnClickListener(v -> Toast.makeText(this, "You earned R0.00 today", Toast.LENGTH_SHORT).show());
    }
}